package com.example.rickandmorty.activities

import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.rickandmorty.*
import java.io.InputStream
import java.net.URL

class CharacterActivity : AppCompatActivity() {
    lateinit var layoutManager: LinearLayoutManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_character)

        val description = intent.getStringArrayListExtra("CharacterData")
        val episodes = intent.getStringArrayListExtra("CharacterEpis")
        val eps: ArrayList<String> = episodes as ArrayList<String>
        Log.d("episodes", eps.toString())

        val adapter by lazy { EpisodeAdapter() }
        val model = EpisodeViewModel(episodes)

        val recyclerView: RecyclerView = findViewById(R.id.ep_rView)
        layoutManager = LinearLayoutManager(this)

        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter

       // val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar2)
       // setSupportActionBar(toolbar);

        title = description?.get(1)

        val avatarImage: ImageView = findViewById(R.id.avatarAC)
        val name: TextView = findViewById(R.id.nameAC)

        Log.d("desc", description.toString())

        val i: InputStream = URL(description?.get(0)).openStream()
        val image = BitmapFactory.decodeStream(i)
        avatarImage.setImageBitmap(image)

        name.text = description?.get(1)


        model.episodeList.observe(this, Observer {
            adapter.submitList(it)
        })
    }
}